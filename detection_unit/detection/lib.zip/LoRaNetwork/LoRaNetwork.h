/*
 LoRaNetwork.h - A Reliable Wireless LoRa Abstraction for the Adafruit Feather LoRa 32u4
 Copyright (c) 2018 Warren Seto.  All right reserved.
 Special Thanks to Adafruit, Arduino and StackOverflow for making this possible!

 Purpose: The Network Structure is designed to be an abstraction over the RadioHead APIs for Senior Project.
 
 Public Methods:
 Network.init(); // The ID of the node will be read via the Arduino's EEPROM (TODO)
 void send_count(uint8_t count);
 void send_battery(uint8_t level);
 void send_error(uint8_t code);
 
 To Setup: 1. In the main Arduino file (.ino or .pde) declare a Network structure variable.
 2. Call the init() method to get the radios ready
 
 To Send Data: Call the payload specific send_X method to send specific data to the Cloud
 
 Performance Characteristics: Not yet documented
 */

#ifndef LoRaNetwork_h
#define LoRaNetwork_h

/* Libraries REQUIRED for Radio Communication AND Reliability */
#include <RH_RF95.h>
#include <RHReliableDatagram.h>

/* EEPROM for Node ID */
#include <EEPROM.h>

//#define RADIO_SET 3   // Use for ARM M0 devices
#define RADIO_SET 7     // Use for 32u4 devices
#define RADIO_POWER 23  // Transmit Power [0...23]

struct Network
{
private:
    RH_RF95 radio;
    RHReliableDatagram manager;
    char ID[5];
    
public:
    Network() : radio(8, RADIO_SET),
                manager(radio, 2) {}
    
    void init()
    {
        pinMode(4, OUTPUT);
        digitalWrite(4, HIGH);
        
        if (!manager.init()) {}
        
        // "American ISM" @ 915MHz
        if (!radio.setFrequency(915.0)) {}
        
        // Sets the radio's transmit power
        radio.setTxPower(RADIO_POWER, false);
        
        // Sets Node ID from EEPROM[0...4]
        for (int count = 0; count < 5; count++)
        {
            ID[count] = EEPROM.read(count);
        }
    }
    
    // Sends the held count for a given parking lot
    void send_count(uint8_t count)
    {
        send_byte('=', count);
    }
    
    // Sends the current battery level
    void send_battery(uint8_t level)
    {
        send_byte('~', level);
    }
    
    // Sends a designated error code
    void send_error(uint8_t code)
    {
        send_byte('>', code);
    }
    
    // Turns the radio off. Automatically wakes up on transmit
    void sleep()
    {
        radio.sleep();
    }
    
    inline void send_byte(char type, uint8_t num)
    {
        char buffer[8];                 // [0 0 0 0 0 0 0 0]
        memcpy(buffer, ID, 4);          // [A B C D 0 0 0 0]
        buffer[4] = type;               // [A B C D = 0 0 0]
        itoa(num, buffer + 5, 10);      // [A B C D = 2 5 5]
        
        manager.sendtoWait((uint8_t *)buffer, 8, 2);
    }
};

#endif
